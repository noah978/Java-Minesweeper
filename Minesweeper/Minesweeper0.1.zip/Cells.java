import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Cells here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Cells extends Actor
{
    private GreenfootImage GraySquare;
    private GreenfootImage ClickedSquare;
    private GreenfootImage RedMine;
    private GreenfootImage Flagged;
    private GreenfootImage NotMine;
    private GreenfootImage Mine;
    private String cellType;
    public Cells()
    {
        GraySquare= new GreenfootImage("GreySquareNormal.png");
        ClickedSquare= new GreenfootImage("DepressedGraySquare.png");
        RedMine= new GreenfootImage("RedMine.png");
        Flagged= new GreenfootImage("FlaggedSquare.png");
        NotMine= new GreenfootImage("NotMine.png");
        Mine= new GreenfootImage("MineSquare.png");
        setImage(GraySquare);
        cellType="normal";
    }
    /**
     * Act - do whatever the Cells wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        clickCheck();
    }
    public void clickCheck()
    {
        MouseInfo ms = Greenfoot.getMouseInfo();
        int fin=0;
        if (ms!=null)
        {
            if (ms.getX()==this.getX() && ms.getY()==this.getY())
            {
                if (cellType.equals("normal") && ms.getButton()==1 && Greenfoot.mouseClicked(this) && fin==0)
                {
                    setImage(ClickedSquare);
                    cellType="clicked";
                    fin++;
                }
                if (cellType.equals("flagged") && !cellType.equals("clicked") && ms.getButton()==3 && Greenfoot.mouseClicked(this) && fin==0)
                {
                    setImage(GraySquare);
                    cellType="normal";
                    fin++;
                }
                if (cellType.equals("normal") && !cellType.equals("clicked") && ms.getButton()==3 && Greenfoot.mouseClicked(this) && fin==0)
                {
                    setImage(Flagged);
                    cellType="flagged";
                    fin++;
                }
            }
        }
    }
}
