import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MyWorld extends World
{
    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public MyWorld()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(60, 30, 16); 
        createCells();
    }
    public void generateMines()
    {
        for (int x=0; x<46; x++)
        {
            addObject(new transparentMine(), (Greenfoot.getRandomNumber(61)), (Greenfoot.getRandomNumber(31)));
        }
    }
    public void createCells()
    {
        for (int x=0; x<=60; x++)
        {
            for (int y=0; y<=30; y++)
            {
                addObject(new Cells(), x, y);
            }
        }
    }
}
